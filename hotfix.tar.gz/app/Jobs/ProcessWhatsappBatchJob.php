<?php

namespace App\Jobs;

use App\Models\WhatsappMessage;
use App\Models\MarketplaceListing;
use App\Models\WhatsappGroup;
use App\Models\WhatsappUser;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ProcessWhatsappBatchJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $userId;
    protected $groupId;

    /**
     * Create a new job instance.
     */
    public function __construct($userId, $groupId)
    {
        $this->userId = $userId;
        $this->groupId = $groupId;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        try {
            // Retrieve all unprocessed messages for this user in this group
            $messages = WhatsappMessage::where('whatsapp_user_id', $this->userId)
                ->where('group_id', $this->groupId)
                ->where('batch_processed', false)
                ->get();

            if ($messages->isEmpty()) {
                return;
            }

            // Mark as processed immediately to avoid concurrent job collision
            WhatsappMessage::whereIn('id', $messages->pluck('id'))->update([
                'batch_processed' => true,
                'status' => 'processing'
            ]);

            $group = WhatsappGroup::where('group_id', $this->groupId)->first();
            $user = WhatsappUser::find($this->userId);

            $combinedText = '';
            $allMedias = [];
            $messageIds = [];

            foreach ($messages as $msg) {
                $combinedText .= $msg->content . "\n";
                if (!empty($msg->medias)) {
                    $allMedias = array_merge($allMedias, $msg->medias);
                }
                $messageIds[] = $msg->id;
            }

            // Validation: ONLY process messages that contain at least one photo.
            // Text-only messages are ignored — a photo is mandatory for a listing.
            $hasMeaningfulText = strlen(trim(str_replace(['[Média]', '[Message non texte]'], '', $combinedText))) > 5;
            $hasMedia = count($allMedias) > 0;

            if (!$hasMedia) {
                WhatsappMessage::whereIn('id', $messageIds)->update([
                    'status'    => 'ignored',
                    'error_log' => 'Ignoré: Aucune photo. Seules les annonces avec photo sont traitées.'
                ]);
                return;
            }

            // If images are present but text is short/empty, let the AI generate from images alone
            if (!$hasMeaningfulText) {
                $combinedText = '[Annonce sans texte - analyse uniquement les images pour créer une annonce complète]';
            }

            // AI Processing
            $apiKey = config('services.groq.api_key');
            $endpoint = config('services.groq.endpoint', 'https://api.groq.com/openai/v1/chat/completions');
            $model = config('services.groq.model', 'llama-3.3-70b-versatile');

            if (empty($apiKey)) {
                throw new \Exception('GROQ API key is missing.');
            }

            // Load real categories from DB for the AI prompt
            $parentCats = \App\Models\MarketplaceCategory::whereNull('parent_id')
                ->with('children')
                ->orderBy('order_index')
                ->get();

            $categoryList = '';
            $subCategoryList = '';
            foreach ($parentCats as $pCat) {
                $categoryList .= "  - {$pCat->name} ({$pCat->label})\n";
                foreach ($pCat->children as $child) {
                    $subCategoryList .= "  - {$child->name} ({$child->label}) → parent: {$pCat->name}\n";
                }
            }

            
            $systemPrompt = "Tu es un assistant spécialisé dans l'extraction de données pour une marketplace. Ton rôle est d'analyser un ensemble de textes et de photos envoyés par un utilisateur sur WhatsApp.
Tu dois déterminer s'il s'agit d'annonces commerciales (vente, location, services).
L'utilisateur peut proposer un seul article (avec plusieurs photos) OU plusieurs articles totalement différents (ex: une voiture ET un téléphone).
S'il y a plusieurs articles différents, tu dois OBLIGATOIREMENT créer une annonce pour CHAQUE article, et donc retourner un TABLEAU de plusieurs objets.
TRADUCTION OBLIGATOIRE : Si le texte original est en anglais, dioula, nouchi, le titre et la description doivent être en bon français.
Si le texte ne contient que '[Annonce sans texte - analyse uniquement les images]', base-toi EXCLUSIVEMENT sur ce que tu vois sur les images pour deviner le titre, la description, le prix, la marque, etc.

Tu dois évaluer les photos. Chaque image t'est passée avec un index [Image 1], [Image 2], etc.
Pour chaque article que tu trouves, indique dans `image_indices` la liste des numéros d'images qui montrent cet article. Si une image est floue ou inutile, ne l'inclus pas.
Si tu détectes une contradiction (ex: texte dit 'Toyota' mais l'image montre 'Mercedes'), corrige la marque et ajoute une alerte dans `brand_mismatch_alert`.

Catégories disponibles (utilise EXACTEMENT ces valeurs) :
{$categoryList}

Sous-catégories disponibles (utilise EXACTEMENT ces valeurs) :
{$subCategoryList}

Tu dois renvoyer UNIQUEMENT un TABLEAU (ARRAY) D'OBJETS JSON. N'ajoute AUCUN texte avant ou après.
Format JSON attendu :
[
  {
    \"is_commercial\": true,
    \"category\": \"string\",
    \"sub_category\": \"string\",
    \"type\": \"string (SALE, RENT, SEARCH, SERVICE)\",
    \"title\": \"string\",
    \"description\": \"string\",
    \"price\": 0,
    \"price_unit\": \"FCFA\",
    \"brand\": \"string\",
    \"model\": \"string\",
    \"year\": \"string\",
    \"location_city\": \"string\",
    \"owner_name\": \"string\",
    \"confidence_score\": 80,
    \"image_indices\": [1, 2],
    \"brand_mismatch_alert\": null
  }
]";

            $contentString = $systemPrompt . "

TEXTE DE L'UTILISATEUR:
" . $combinedText;
            
            // Make the unified API call
            $response = Http::withToken($apiKey)->timeout(60)->post($endpoint, [
                'model' => 'llama-3.3-70b-versatile',
                'messages' => [
                    ['role' => 'user', 'content' => $contentString]
                ],
                'temperature' => 0.1,
                'response_format' => ['type' => 'json_object']
            ]);

            if ($response->failed()) {
                throw new \Exception('Groq API Error: ' . $response->body());
            }

            $aiContent = $response->json()['choices'][0]['message']['content'] ?? '[]';
            $aiContent = trim(preg_replace('/^```json\s*(.*?)\s*```$/is', '$1', $aiContent));
            
            $dataArray = json_decode($aiContent, true);

            if (json_last_error() !== JSON_ERROR_NONE || !is_array($dataArray)) {
                throw new \Exception('Invalid JSON from AI (expected Array): ' . json_last_error_msg() . " -> " . $aiContent);
            }

            // Groq with json_object cannot return a raw array — it always wraps in an object.
            // Unwrap: if we received an object, find the first array value (e.g. {"listings": [...], "annonces": [...]})
            if (!isset($dataArray[0]) && !array_is_list($dataArray)) {
                // Direct single listing object (has 'title' or 'category' key)
                if (isset($dataArray['title']) || isset($dataArray['category'])) {
                    $dataArray = [$dataArray];
                } else {
                    // Find first array-valued key
                    $found = null;
                    foreach ($dataArray as $val) {
                        if (is_array($val) && (isset($val[0]) || empty($val))) {
                            $found = $val;
                            break;
                        }
                    }
                    $dataArray = $found ?? [$dataArray];
                }
            }


            // Mode insertion configuré dans le groupe
            $insertMode = $group ? $group->insert_mode : 'ACTIVE';
            $listingStatus = ($insertMode === 'PENDING_VALIDATION') ? 'PENDING_VALIDATION' : 'ACTIVE';


            
            // Upload ALL images to the web pod via internal HTTP endpoint
            // (worker and web pods have separate local filesystems; we POST the base64
            //  image to the web pod which saves it and returns the public URL)
            $finalMediasUrls = [];
            $webPodUrl    = env('INTERNAL_WEB_URL', 'http://laravel-service');
            $internalSecret = env('INTERNAL_API_SECRET', 'picme225-internal-secret');
            foreach ($allMedias as $index => $mediaBase64) {
                if (!empty($mediaBase64)) {
                    try {
                        $uploadResp = Http::withHeaders([
                            'X-Internal-Secret' => $internalSecret,
                        ])->timeout(30)->post("{$webPodUrl}/api/user/internal/upload-image", [
                            'data' => $mediaBase64,
                        ]);
                        if ($uploadResp->successful()) {
                            $finalMediasUrls[$index + 1] = $uploadResp->json('url');
                        } else {
                            Log::warning('Image upload to web pod failed', [
                                'index' => $index,
                                'status' => $uploadResp->status(),
                                'body' => substr($uploadResp->body(), 0, 200),
                            ]);
                        }
                    } catch (\Exception $uploadEx) {
                        Log::warning('Image upload exception: ' . $uploadEx->getMessage());
                    }
                }
            }

            // Loop over every listing identified by the AI
            foreach ($dataArray as $data) {
                if (!isset($data['is_commercial']) || $data['is_commercial'] === false) {
                    continue; // Skip non-commercial blocks
                }
                
                $confidence = $data['confidence_score'] ?? 0;
                $adminAlert = $data['brand_mismatch_alert'] ?? null;
                
                // Assign mapped images
                $listingMedias = [];
                if (isset($data['image_indices']) && is_array($data['image_indices'])) {
                    foreach ($data['image_indices'] as $imgIndex) {
                        if (isset($finalMediasUrls[$imgIndex])) {
                            $listingMedias[] = $finalMediasUrls[$imgIndex];
                        }
                    }
                }
                
                // Fallback: If AI gave no valid indices, attach ALL images (better than no images)
                if (empty($listingMedias)) {
                    $listingMedias = array_values($finalMediasUrls);
                }
                
                $coverImage = !empty($listingMedias) ? $listingMedias[0] : null;
                
                // Determine Category
                $category = $data['category'] ?? ($group ? $group->default_category : 'AUTRE');
                $subCategory = $data['sub_category'] ?? null;
                
                $catModel = \App\Models\MarketplaceCategory::where('name', $category)
                    ->orWhere('label', $category)
                    ->first();
                if (!$catModel) {
                    $catModel = \App\Models\MarketplaceCategory::where('name', 'AUTRE')->first();
                }
                $categoryId = $catModel ? $catModel->id : null;

                $listing = new MarketplaceListing();
                $listing->user_id = $user->id;
                $listing->owner_phone = $user->phone_number;
                $listing->owner_name = $data['owner_name'] ?? $user->name;
                $listing->whatsapp_message_id = !empty($messageIds) ? $messageIds[0] : null;
                $listing->type = $data['type'] ?? 'SALE';
                $listing->category = $category;
                $listing->sub_category = $subCategory;
                $listing->title = $data['title'] ?? 'Annonce';
                $listing->description = $data['description'] ?? '';
                $listing->price = (float) ($data['price'] ?? 0);
                $listing->price_unit = $data['price_unit'] ?? 'FCFA';
                $listing->brand = $data['brand'] ?? null;
                $listing->model = $data['model'] ?? null;
                $listing->year = $data['year'] ?? null;
                $listing->location_city = $data['location_city'] ?? null;
                $listing->status = $listingStatus;
                $listing->source = 'whatsapp';
                $listing->ai_confidence_score = $confidence;
                $listing->cover_image = $coverImage;
                $listing->images = $listingMedias;
                
                $metadata = $data['metadata'] ?? [];
                if (!is_array($metadata)) {
                    $metadata = [];
                }
                if ($adminAlert) {
                    $metadata['ai_brand_mismatch_alert'] = $adminAlert;
                }
                $listing->metadata = $metadata;

                $listing->save();

                // Notify User via WhatsApp (per listing)
                $this->notifyUser($user->phone_number, $listing, $user);

                // Notify Admin for 1-click validation (only if listing requires validation)
                if ($listing->status === 'PENDING_VALIDATION') {
                    $this->notifyAdminForValidation($listing);
                }

                // Auto-post to Social Media if listing goes directly ACTIVE
                if ($listing->status === 'ACTIVE') {
                    \App\Jobs\PostToSocialMediaJob::dispatch($listing->id);
                }

                // Log for metrics
                \Illuminate\Support\Facades\Log::info("Nouvelle annonce créée depuis WhatsApp", [
                    'listing_id' => $listing->id,
                    'user_phone' => $user->phone_number
                ]);
            }



            WhatsappMessage::whereIn('id', $messageIds)->update([
                'status' => 'success',
                'error_log' => null,
            ]);

        } catch (\Exception $e) {
            Log::error('WhatsApp Batch Job Error: ' . $e->getMessage());
            WhatsappMessage::whereIn('id', $messageIds ?? [])->update([
                'status' => 'failed',
                'error_log' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Resolve Evolution API connection settings.
     * Falls back through config → env → hardcoded defaults so the job always works
    /**
     * Resolve Evolution API connection settings.
     * Uses env() directly (with hardcoded fallbacks) because config() is unreliable
     * inside the K8s worker pod when the config cache has not been built.
     */
    private function getEvoConfig(): array
    {
        // Read ENV directly — DO NOT use config() here; the worker pod has no compiled config cache.
        $url  = env('EVOLUTION_API_URL',  'http://evolution-api-service:8080');
        $key  = env('EVOLUTION_API_KEY',  'picme225-evolution-secret-key');
        $inst = env('EVOLUTION_INSTANCE', 'picme_whatsapp');
        return [$url, $key, $inst];
    }

    /**
     * Resolve the best WhatsApp JID to use for sending a message to a user.
     * WhatsApp's new LID (Linked Identity) protocol requires using the @lid identifier
     * for contacts who use recent versions of WhatsApp. We look up recent messages
     * from this user in our group chats to find their LID, which actually delivers.
     * Falls back to standard @s.whatsapp.net format if LID is not found.
     */
    private function resolveWhatsappJid(string $phoneNumber): string
    {
        // Strip any existing suffixes
        $rawPhone = str_replace(['@s.whatsapp.net', '@lid', '@g.us'], '', $phoneNumber);

        // Fallback: standard phone format
        if (strlen($rawPhone) >= 14) {
            return $rawPhone . '@lid';
        }
        return $rawPhone . '@s.whatsapp.net';
    }

    private function notifyUser($whatsappId, $listing, $user)
    {
        [$evoApiUrl, $evoApiKey, $instanceName] = $this->getEvoConfig();

        if (!$evoApiUrl || !$evoApiKey) {
            Log::warning('Evolution API not configured for notifications.');
            return;
        }

        $appPublicUrl = rtrim(env('APP_PUBLIC_URL', 'https://www.picme225.site'), '/');
        $listingUrl   = $appPublicUrl . '/marketplace/' . $listing->id;

        if ($listing->status === 'PENDING_VALIDATION') {
            $messageText = "🆕 *Nouvelle annonce en cours de validation*\n\n";
            $messageText .= "Votre annonce a bien été reçue et est actuellement en cours de validation par notre équipe. Elle sera publiée dès qu'elle aura été approuvée.\n\n";
            $messageText .= "📦 *{$listing->title}*\n";
            $messageText .= "🏷️ Catégorie : {$listing->category}\n";
            $messageText .= "💰 Prix : " . number_format((float)$listing->price, 0, ',', ' ') . " {$listing->price_unit}\n";
            if ($listing->location_city) {
                $messageText .= "📍 Lieu : {$listing->location_city}\n";
            }
        } else {
            $messageText = "✅ *Votre annonce a été validée*\n\n";
            $messageText .= "Félicitations ! Votre annonce a été validée et est maintenant visible par tous les utilisateurs sur PickMe225.\n\n";
            $messageText .= "🔗 Voir mon annonce : {$listingUrl}\n";
            $messageText .= "🔄 Partager mon annonce : {$listingUrl}";
        }

        // Always use phone_number@s.whatsapp.net for private messages — this format works reliably.
        // LID (@lid) stored in whatsapp_id causes ERROR on private sends.
        $rawPhone = '';
        if ($user && $user->phone_number) {
            $rawPhone = preg_replace('/[^0-9]/', '', $user->phone_number);
        } else {
            $rawPhone = preg_replace('/[^0-9]/', '', str_replace(['@s.whatsapp.net', '@lid', '@g.us'], '', $whatsappId));
        }
        $sendToJid = $rawPhone . '@s.whatsapp.net';

        try {
            $resp = Http::withHeaders(['apikey' => $evoApiKey])
                ->timeout(15)
                ->post("{$evoApiUrl}/message/sendText/{$instanceName}", [
                    'number'  => $sendToJid,
                    'text'    => $messageText,
                    'options' => [
                        'delay'    => 1200,
                        'presence' => 'composing',
                    ],
                ]);

            if ($resp->successful()) {
                Log::info('notifyUser: message envoyé avec succès', [
                    'listing_id' => $listing->id,
                    'to'         => $sendToJid,
                    'status'     => $resp->status(),
                ]);
            } else {
                Log::warning('notifyUser: échec envoi message', [
                    'listing_id' => $listing->id,
                    'to'         => $sendToJid,
                    'status'     => $resp->status(),
                    'body'       => substr($resp->body(), 0, 500),
                ]);
            }
        } catch (\Exception $e) {
            Log::error('notifyUser exception: ' . $e->getMessage());
        }
    }

    private function notifyAdminForValidation($listing)
    {
        [$evoApiUrl, $evoApiKey, $instanceName] = $this->getEvoConfig();

        // Admin phone: 22559747444 (format validé par WhatsApp)
        $adminPhone = '22559747444@s.whatsapp.net';

        if (!$evoApiUrl || !$evoApiKey) return;

        $logoPath = public_path('logo.png');
        $base64Logo = '';
        if (file_exists($logoPath)) {
            $base64Logo = base64_encode(file_get_contents($logoPath));
        }

        $msg = "🛡️ *Nouvelle annonce à valider* 🛡️\n\n";
        $msg .= "Une nouvelle annonce a été soumise par un utilisateur et est en attente de validation :\n\n";
        $msg .= "📦 *{$listing->title}*\n";
        $msg .= "👤 Vendeur: {$listing->owner_name} ({$listing->owner_phone})\n";
        $msg .= "🏷️ Catégorie: {$listing->category}\n";
        $msg .= "💰 Prix: " . number_format((float)$listing->price, 0, ',', ' ') . " {$listing->price_unit}\n\n";
        $msg .= "➡️ Répondez *OUI {$listing->id}* pour publier.\n";
        $msg .= "➡️ Répondez *NON {$listing->id}* pour rejeter.";

        try {
            $resp = Http::withHeaders(['apikey' => $evoApiKey])
                ->timeout(15)
                ->post("{$evoApiUrl}/message/sendText/{$instanceName}", [
                    'number' => $adminPhone,
                    'options' => [
                        'delay' => 1200,
                        'presence' => 'composing'
                    ],
                    'text' => $msg,
                ]);
            
            Log::info('notifyAdmin: résultat envoi', [
                'listing_id' => $listing->id,
                'to'         => $adminPhone,
                'status'     => $resp->status(),
            ]);
        } catch (\Exception $e) {
            Log::error('notifyAdmin exception: ' . $e->getMessage());
        }
    }
}
